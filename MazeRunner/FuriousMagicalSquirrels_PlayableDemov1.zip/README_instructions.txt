How to play:

Press the WASD keys to move. 

Press the spacebar to jump over obstacles. 

Press R to throw a stun bomb. You start with 3 at the beginning of each level. 

Move through the maze and try to find the 'finish line', which is a campfire.

To win the level, touch the campfire before the AIs do. There are 3 levels. 

Target platform: Windows
Control method: keyboard